package com.dodosadventure.autosketch

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/**
 * Kotak mengambang: geser di mana saja untuk memindah,
 * tarik segitiga di pojok kanan-bawah untuk mengubah ukuran.
 */
class BoxView(ctx: Context, private val bmp: Bitmap?) : View(ctx) {
    var previewVisible = true
    var onMove: ((Int, Int) -> Unit)? = null
    var onResize: ((Int, Int) -> Unit)? = null

    private val d = ctx.resources.displayMetrics.density
    private val handle = (48 * d).toInt()
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 120 }
    private val borderPaint = Paint().apply {
        color = 0xFF00E5FF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 3 * d
    }
    private val handlePaint = Paint().apply {
        color = 0xFF00E5FF.toInt()
        style = Paint.Style.FILL
    }
    private var mode = 0
    private var lastX = 0f
    private var lastY = 0f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (previewVisible && bmp != null) {
            val s = min(w / bmp.width, h / bmp.height)
            val dw = bmp.width * s
            val dh = bmp.height * s
            val l = (w - dw) / 2f
            val t = (h - dh) / 2f
            c.drawBitmap(bmp, null, RectF(l, t, l + dw, t + dh), bitmapPaint)
        }
        c.drawRect(1.5f * d, 1.5f * d, w - 1.5f * d, h - 1.5f * d, borderPaint)
        val p = Path().apply {
            moveTo(w, h - handle)
            lineTo(w, h)
            lineTo(w - handle, h)
            close()
        }
        c.drawPath(p, handlePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                mode = if (e.x > width - handle && e.y > height - handle) 2 else 1
                lastX = e.rawX
                lastY = e.rawY
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                lastX = e.rawX
                lastY = e.rawY
                if (mode == 2) onResize?.invoke(dx, dy) else onMove?.invoke(dx, dy)
            }
        }
        return true
    }
}
