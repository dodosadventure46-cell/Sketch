package com.dodosadventure.autosketch

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "Auto Sketch"
            textSize = 24f
        })
        status = TextView(this).apply { setPadding(0, dp(8), 0, dp(8)) }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "Android 13+: jika layanan abu-abu/tidak bisa diaktifkan, buka Info aplikasi > menu titik tiga > \"Izinkan setelan terbatas\", lalu coba lagi."
            textSize = 12f
        })

        root.addView(button("1. Aktifkan layanan Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("2. Pilih gambar sketsa") {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            @Suppress("DEPRECATION")
            startActivityForResult(i, 1)
        })

        preview = ImageView(this).apply {
            adjustViewBounds = true
            maxHeight = dp(180)
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(preview)

        root.addView(Switch(this).apply {
            text = "Mode line art (garis gelap di latar terang)"
            isChecked = prefs.getBoolean("lineArt", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("lineArt", c).apply() }
        })

        addSeek(root, "Detail (resolusi garis)", "detail", 40, 300, 120)
        addSeek(root, "Ambang (naik = garis lebih sedikit)", "thr", 10, 200, 80)
        addSeek(root, "Kecepatan menggambar", "speed", 1, 10, 5)

        root.addView(button("3. Tampilkan kotak mengambang") {
            val svc = AutoDrawService.instance
            if (svc == null) {
                Toast.makeText(this, "Aktifkan layanan Accessibility dulu", Toast.LENGTH_LONG).show()
            } else if (svc.showOverlay()) {
                moveTaskToBack(true)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (AutoDrawService.instance != null) {
            "Accessibility: AKTIF"
        } else {
            "Accessibility: belum aktif"
        }
        val f = File(filesDir, "sketch.png")
        if (f.exists()) preview.setImageBitmap(BitmapFactory.decodeFile(f.path))
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun addSeek(root: LinearLayout, label: String, key: String, lo: Int, hi: Int, def: Int) {
        val value = prefs.getInt(key, def)
        val tv = TextView(this).apply {
            text = "$label: $value"
            setPadding(0, dp(12), 0, 0)
        }
        val sb = SeekBar(this).apply {
            max = hi - lo
            progress = value - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + lo
                    tv.text = "$label: $v"
                    prefs.edit().putInt(key, v).apply()
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(tv)
        root.addView(sb)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 1 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > 1200) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
            if (bmp == null) {
                Toast.makeText(this, "Gagal membuka gambar", Toast.LENGTH_SHORT).show()
                return
            }
            FileOutputStream(File(filesDir, "sketch.png")).use {
                bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
            }
            preview.setImageBitmap(bmp)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memuat gambar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
