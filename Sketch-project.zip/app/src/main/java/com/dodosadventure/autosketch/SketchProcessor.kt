package com.dodosadventure.autosketch

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Mengubah gambar menjadi daftar goresan (stroke).
 * Koordinat hasil relatif terhadap pojok kiri-atas kotak (dalam piksel layar).
 */
object SketchProcessor {
    private val DX = intArrayOf(1, 1, 0, -1, -1, -1, 0, 1)
    private val DY = intArrayOf(0, 1, 1, 1, 0, -1, -1, -1)

    fun trace(
        src: Bitmap,
        boxW: Int,
        boxH: Int,
        detail: Int,
        threshold: Int,
        lineArt: Boolean
    ): List<List<PointF>> {
        val ratio = detail.toFloat() / max(src.width, src.height)
        val gw = max(8, (src.width * ratio).roundToInt())
        val gh = max(8, (src.height * ratio).roundToInt())
        val small = Bitmap.createScaledBitmap(src, gw, gh, true)
        val px = IntArray(gw * gh)
        small.getPixels(px, 0, gw, 0, 0, gw, gh)

        val gray = IntArray(gw * gh) { i ->
            val c = px[i]
            if (Color.alpha(c) < 128) 255
            else (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)).toInt()
        }

        val edge = BooleanArray(gw * gh)
        if (lineArt) {
            val limit = 255 - threshold
            for (i in gray.indices) edge[i] = gray[i] < limit
        } else {
            for (y in 1 until gh - 1) {
                for (x in 1 until gw - 1) {
                    val i = y * gw + x
                    val gx = -gray[i - gw - 1] + gray[i - gw + 1] -
                        2 * gray[i - 1] + 2 * gray[i + 1] -
                        gray[i + gw - 1] + gray[i + gw + 1]
                    val gy = -gray[i - gw - 1] - 2 * gray[i - gw] - gray[i - gw + 1] +
                        gray[i + gw - 1] + 2 * gray[i + gw] + gray[i + gw + 1]
                    edge[i] = (abs(gx) + abs(gy)) / 4 > threshold
                }
            }
        }

        val fit = min(boxW.toFloat() / gw, boxH.toFloat() / gh)
        val ox = (boxW - gw * fit) / 2f
        val oy = (boxH - gh * fit) / 2f

        val visited = BooleanArray(gw * gh)
        val result = ArrayList<List<PointF>>()

        for (start in edge.indices) {
            if (!edge[start] || visited[start]) continue
            val idxs = ArrayList<Int>()
            var cur = start
            var dir = -1
            visited[cur] = true
            idxs.add(cur)
            while (true) {
                val cx = cur % gw
                val cy = cur / gw
                var best = -1
                var bestK = -1
                var bestScore = -1
                for (k in 0 until 8) {
                    val nx = cx + DX[k]
                    val ny = cy + DY[k]
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    val ni = ny * gw + nx
                    if (!edge[ni] || visited[ni]) continue
                    val score = if (dir < 0) 4 else {
                        val d = abs(k - dir)
                        4 - min(d, 8 - d)
                    }
                    if (score > bestScore) {
                        bestScore = score
                        best = ni
                        bestK = k
                    }
                }
                if (best < 0) break
                cur = best
                dir = bestK
                visited[cur] = true
                idxs.add(cur)
            }
            if (idxs.size >= 3) {
                val pts = ArrayList<PointF>()
                var i = 0
                while (i < idxs.size) {
                    val p = idxs[i]
                    pts.add(PointF(ox + ((p % gw) + 0.5f) * fit, oy + ((p / gw) + 0.5f) * fit))
                    i += 2
                }
                if ((idxs.size - 1) % 2 != 0) {
                    val p = idxs[idxs.size - 1]
                    pts.add(PointF(ox + ((p % gw) + 0.5f) * fit, oy + ((p / gw) + 0.5f) * fit))
                }
                result.add(pts)
            }
        }
        return result
    }
}
